#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <chrono>
#include <iostream>
#include <random>
#include <vector>

void fillRandom(float *data, int size) {
    for (int i = 0; i < size; i++) {
        data[i] = (float)rand() / RAND_MAX * 2.0 - 1.0;
    }
}

void matrixVectorMultiply(float *A, float *x, float *y, int n) {
    for (int i = 0; i < n; i++) {
        y[i] = 0;
        for (int j = 0; j < n; j++) {
            y[i] += A[i * n + j] * x[j];
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <matrix size>\n", argv[0]);
        return 1;
    }

    int i = atoi(argv[1]);
    int n = 1024 * i;

    float *A = (float *)malloc(n * n * sizeof(float));
    float *x = (float *)malloc(n * sizeof(float));
    float *y = (float *)malloc(n * sizeof(float));

    srand(time(NULL));

    fillRandom(A, n * n);
    fillRandom(x, n);

    clock_t start = clock();
    matrixVectorMultiply(A, x, y, n);
    clock_t end = clock();

    double elapsed_time = (double)(end - start) / CLOCKS_PER_SEC;

    FILE *fp = fopen("output.csv", "a");
    if (fp != NULL) {
        fprintf(fp, "%d,%f\n", n, elapsed_time);
        fclose(fp);
    } else {
        return 1;
    }

    free(A);
    free(x);
    free(y);

    return 0;
}