#!/bin/bash

g++ -o exe main.cpp

rm -f output.csv
touch output.csv

echo "Matrix Size, Execution Time" >> output.csv

for i in 1 4 8 16
do
    ./exe $i
done
